---
title: Apache Mesos - HTTP Endpoints - /files/debug
layout: documentation
---
<!--- This is an automatically generated file. DO NOT EDIT! --->

### USAGE ###
>        /files/debug

### TL;DR; ###
Returns the internal virtual path mapping.

### DESCRIPTION ###
This endpoint shows the internal virtual path map as a
JSON object.


### AUTHENTICATION ###
This endpoint requires authentication iff HTTP authentication is
enabled.

### AUTHORIZATION ###
The request principal should be authorized to query this endpoint.
See the authorization documentation for details.