---
title: Apache Mesos - HTTP Endpoints - /flags
layout: documentation
---
<!--- This is an automatically generated file. DO NOT EDIT! --->

### USAGE ###
>        /flags
>        /slave(1)/flags

### TL;DR; ###
Exposes the agent's flag configuration.

### AUTHENTICATION ###
This endpoint requires authentication iff HTTP authentication is
enabled.

### AUTHORIZATION ###
The request principal should be authorized to view all flags.
See the authorization documentation for details.