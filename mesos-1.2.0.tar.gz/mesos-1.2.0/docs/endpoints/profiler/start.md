---
title: Apache Mesos - HTTP Endpoints - /profiler/start
layout: documentation
---
<!--- This is an automatically generated file. DO NOT EDIT! --->

### USAGE ###
>        /profiler/start

### TL;DR; ###
Start profiling.

### DESCRIPTION ###
Start to use google perftools do profiling.


### AUTHENTICATION ###
This endpoint requires authentication iff HTTP authentication is
enabled.