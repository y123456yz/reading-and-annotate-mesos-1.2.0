---
title: Apache Mesos - HTTP Endpoints - /profiler/stop
layout: documentation
---
<!--- This is an automatically generated file. DO NOT EDIT! --->

### USAGE ###
>        /profiler/stop

### TL;DR; ###
Stops profiling.

### DESCRIPTION ###
Stop to use google perftools do profiling.


### AUTHENTICATION ###
This endpoint requires authentication iff HTTP authentication is
enabled.